﻿Imports System.IO

Public Class FormFile
    Private m_Name, m_ContentType, m_FilePath, m_uploadedFileName As String

    ''' <summary>This is the name for the form entry.</summary>
    Public Property formName() As String
        Get
            Return m_Name
        End Get
        Set
            m_Name = Value
        End Set
    End Property

    ''' <summary>This is the content type or MIME type.</summary>
    Public Property contentType() As String
        Get
            Return m_ContentType
        End Get
        Set
            m_ContentType = Value
        End Set
    End Property

    ''' <summary>This is the path to the file to be uploaded on the local file system.</summary>
    Public Property localFilePath() As String
        Get
            Return m_FilePath
        End Get
        Set
            m_FilePath = Value
        End Set
    End Property

    ''' <summary>This sets the name that the uploaded file will be called on the remote server.</summary>
    Public Property remoteFileName() As String
        Get
            Return m_uploadedFileName
        End Get
        Set
            m_uploadedFileName = Value
        End Set
    End Property
End Class

Public Class noMimeTypeFoundException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class localFileAlreadyExistsException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class postDataMissingException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class getDataMissingException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class postDataEntryNotFound
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class getDataEntryNotFound
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class postDataAlreadyExistsException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class getDataAlreadyExistsException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class additionalHeaderNotFoundException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class additionalHeaderAlreadyExistsException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class cookieAlreadyExistsException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class cookieNotFoundException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Public Class noHTTPServerResponseHeadersFoundException
    Inherits Exception

    Public Sub New()
    End Sub

    Public Sub New(message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(message As String, inner As Exception)
        MyBase.New(message, inner)
    End Sub
End Class

Class cookieDetails
    Public cookieData As String, cookieDomain As String
    Public cookiePath As String = "/"
End Class

''' <summary>Allows you to easily POST and upload files to a remote HTTP server without you, the programmer, knowing anything about how it all works. This class does it all for you. It handles adding a User Agent String, additional HTTP Request Headers, string data to your HTTP POST data, and files to be uploaded in the HTTP POST data.</summary>
Public Class httpHelper
    Private strUserAgentString As String = Nothing
    Private boolUseProxy As Boolean = False
    Private httpResponseHeaders As Net.WebHeaderCollection = Nothing
    Private httpDownloadProgressPercentage As Short = 0
    Private remoteFileSize, currentFileSize, bytesPerSecond As Long
    Private httpTimeOut As Long = 5000

    Private additionalHTTPHeaders As New Dictionary(Of String, String)
    Private httpCookies As New Dictionary(Of String, cookieDetails)
    Private postData As New Dictionary(Of String, Object)
    Private getData As New Dictionary(Of String, String)

    ''' <summary>Gets the remote file size.</summary>
    ''' <param name="boolHumanReadable">Optional setting, normally set to True. Tells the function if it should transform the Integer representing the file size into a human readable format.</param>
    ''' <returns>Either a String or a Long containing the remote file size.</returns>
    Public Function getHTTPDownloadRemoteFileSize(Optional boolHumanReadable As Boolean = True) As Object
        If boolHumanReadable = True Then
            Return fileSizeToHumanReadableFormat(remoteFileSize)
        Else
            Return remoteFileSize
        End If
    End Function

    ''' <summary>Gets the current local file's size.</summary>
    ''' <param name="boolHumanReadable">Optional setting, normally set to True. Tells the function if it should transform the Integer representing the file size into a human readable format.</param>
    ''' <returns>Either a String or a Long containing the current local file's size.</returns>
    Public Function getHTTPDownloadLocalFileSize(Optional boolHumanReadable As Boolean = True) As Object
        If boolHumanReadable = True Then
            Return fileSizeToHumanReadableFormat(currentFileSize)
        Else
            Return currentFileSize
        End If
    End Function

    ''' <summary>Creates a new instance of the HTTPPost Class. You will need to set things up for the Class instance using the setProxyMode() and setUserAgent() routines.</summary>
    ''' <example>Dim httpPostObject As New Tom.HTTPPost()</example>
    Public Sub New()
    End Sub

    ''' <summary>Creates a new instance of the HTTPPost Class with some required parameters.</summary>
    ''' <param name="strUserAgentStringIN">This set the User Agent String for the HTTP Request.</param>
    ''' <example>Dim httpPostObject As New Tom.HTTPPost("Microsoft .NET")</example>
    Public Sub New(strUserAgentStringIN As String)
        strUserAgentString = strUserAgentStringIN
    End Sub

    ''' <summary>Creates a new instance of the HTTPPost Class with some required parameters.</summary>
    ''' <param name="strUserAgentStringIN">This set the User Agent String for the HTTP Request.</param>
    ''' <param name="boolUseProxyIN">This tells the Class if you're going to be using a Proxy or not.</param>
    ''' <example>Dim httpPostObject As New Tom.HTTPPost("Microsoft .NET", True)</example>
    Public Sub New(strUserAgentStringIN As String, boolUseProxyIN As Boolean)
        strUserAgentString = strUserAgentStringIN
        boolUseProxy = boolUseProxyIN
    End Sub

    ''' <summary>Tells the HTTPPost Class if you want to use a Proxy or not. </summary>
    ''' <param name="useProxy">True will use a Proxy, False will not.</param>
    Public Sub setProxyMode(useProxy As Boolean)
        boolUseProxy = useProxy
    End Sub

    ''' <summary>Sets a timeout for any HTTP requests in this Class. Normally it's set for 5 seconds.</summary>
    ''' <param name="timeOutIN">The amount of time in seconds (NOT miliseconds) that you want your HTTP requests to timeout in. This function will translate the seconds to miliseconds for you.</param>
    Public Sub setHTTPTimeout(timeOutIN As Short)
        httpTimeOut = timeOutIN * 1000
    End Sub

    ''' <summary>Sets the User Agent String to be used by the HTTPPost Class.</summary>
    ''' <param name="userAgentString">Your User Agent String.</param>
    Public Sub setUserAgent(userAgentString As String)
        strUserAgentString = userAgentString
    End Sub

    ''' <summary>This adds a String variable to your POST data.</summary>
    ''' <param name="strName">The form name of the data to post.</param>
    ''' <param name="strValue">The value of the data to post.</param>
    ''' <param name="throwExceptionIfDataAlreadyExists">This tells the function if it should throw an exception if the data already exists in the POST data.</param>
    ''' <exception cref="postDataMissingException">If this function throws a postDataMissingException, you forgot to add some data for your POST variable.</exception>
    Public Sub addPOSTData(strName As String, strValue As String, Optional throwExceptionIfDataAlreadyExists As Boolean = False)
        If strValue.Trim = Nothing Then Throw New postDataMissingException(String.Format("Data was missing for the {0}{1}{0} POST variable.", Chr(34), strName))

        If postData.ContainsKey(strName) = True And throwExceptionIfDataAlreadyExists = True Then
            Throw New postDataAlreadyExistsException(String.Format("The POST data key named {0}{1}{0} already exists in the POST data.", Chr(34), strName))
        Else
            postData.Remove(strName)
            postData.Add(strName, strValue)
        End If
    End Sub

    ''' <summary>This adds a String variable to your GET data.</summary>
    ''' <param name="strName">The form name of the data to post.</param>
    ''' <param name="strValue">The value of the data to post.</param>
    ''' <exception cref="postDataMissingException">If this function throws a postDataMissingException, you forgot to add some data for your POST variable.</exception>
    Public Sub addGETData(strName As String, strValue As String, Optional throwExceptionIfDataAlreadyExists As Boolean = False)
        If strValue.Trim = Nothing Then Throw New getDataMissingException(String.Format("Data was missing for the {0}{1}{0} GET variable.", Chr(34), strName))

        If getData.ContainsKey(strName) = True And throwExceptionIfDataAlreadyExists = True Then
            Throw New getDataAlreadyExistsException(String.Format("The GET data key named {0}{1}{0} already exists in the GET data.", Chr(34), strName))
        Else
            getData.Remove(strName)
            getData.Add(strName, strValue)
        End If
    End Sub

    ''' <summary>Allows you to add additional headers to your HTTP Request Headers.</summary>
    ''' <param name="strHeaderName">The name of your new HTTP Request Header.</param>
    ''' <param name="strHeaderContents">The contents of your new HTTP Request Header. Be careful with adding data here, invalid data can cause your HTTP Request to fail thus throwing an httpPostException.</param>
    ''' <param name="urlEncodeHeaderContent">Optional setting, normally set to False. Tells the function if it should URLEncode the HTTP Header Contents before setting it.</param>
    ''' <example>httpPostObject.addHTTPHeader("myheader", "my header value")</example>
    ''' <exception cref="additionalHeaderAlreadyExistsException">If this function throws an additionalHeaderAlreadyExistsException, it means that this Class instance already has an Additional HTTP Header of that name in the Class instance.</exception>
    Public Sub addHTTPHeader(strHeaderName As String, strHeaderContents As String, Optional urlEncodeHeaderContent As Boolean = False)
        If doesAdditionalHeaderExist(strHeaderName) = False Then
            If urlEncodeHeaderContent = True Then
                additionalHTTPHeaders.Add(strHeaderName.ToLower, Web.HttpUtility.UrlEncode(strHeaderContents))
            Else
                additionalHTTPHeaders.Add(strHeaderName.ToLower, strHeaderContents)
            End If
        Else
            Throw New additionalHeaderAlreadyExistsException(String.Format("The additional HTTP Header named {0}{1}{0} already exists in the Additional HTTP Headers settings for this Class instance.", Chr(34), strHeaderName))
        End If
    End Sub

    ''' <summary>Allows you to add HTTP cookies to your HTTP Request with a specific path for the cookie.</summary>
    ''' <param name="strCookieName">The name of your cookie.</param>
    ''' <param name="strCookieValue">The value for your cookie.</param>
    ''' <param name="strCookiePath">The path for the cookie.</param>
    ''' <param name="strDomainDomain">The domain for the cookie.</param>
    ''' <param name="urlEncodeHeaderContent">Optional setting, normally set to False. Tells the function if it should URLEncode the cookie contents before setting it.</param>
    ''' <exception cref="cookieAlreadyExistsException">If this function throws a cookieAlreadyExistsException, it means that the cookie already exists in this Class instance.</exception>
    Public Sub addHTTPCookie(strCookieName As String, strCookieValue As String, strDomainDomain As String, strCookiePath As String, Optional urlEncodeHeaderContent As Boolean = False)
        If doesCookieExist(strCookieName) = False Then
            Dim cookieDetails As New cookieDetails

            If urlEncodeHeaderContent = True Then
                cookieDetails.cookieData = Web.HttpUtility.UrlEncode(strCookieValue)
            Else
                cookieDetails.cookieData = strCookieValue
            End If

            cookieDetails.cookieDomain = strDomainDomain
            cookieDetails.cookiePath = strCookiePath

            httpCookies.Add(strCookieName.ToLower, cookieDetails)
        Else
            Throw New cookieAlreadyExistsException(String.Format("The HTTP Cookie named {0}{1}{0} already exists in the settings for this Class instance.", Chr(34), strCookieName))
        End If
    End Sub

    ''' <summary>Allows you to add HTTP cookies to your HTTP Request with a default path of "/".</summary>
    ''' <param name="strCookieName">The name of your cookie.</param>
    ''' <param name="strCookieValue">The value for your cookie.</param>
    ''' <param name="strCookieDomain">The domain for the cookie.</param>
    ''' <param name="urlEncodeHeaderContent">Optional setting, normally set to False. Tells the function if it should URLEncode the cookie contents before setting it.</param>
    ''' <exception cref="cookieAlreadyExistsException">If this function throws a cookieAlreadyExistsException, it means that the cookie already exists in this Class instance.</exception>
    Public Sub addHTTPCookie(strCookieName As String, strCookieValue As String, strCookieDomain As String, Optional urlEncodeHeaderContent As Boolean = False)
        If doesCookieExist(strCookieName) = False Then
            Dim cookieDetails As New cookieDetails

            If urlEncodeHeaderContent = True Then
                cookieDetails.cookieData = Web.HttpUtility.UrlEncode(strCookieValue)
            Else
                cookieDetails.cookieData = strCookieValue
            End If

            cookieDetails.cookieDomain = strCookieDomain
            cookieDetails.cookiePath = "/"

            httpCookies.Add(strCookieName.ToLower, cookieDetails)
        Else
            Throw New cookieAlreadyExistsException(String.Format("The HTTP Cookie named {0}{1}{0} already exists in the settings for this Class instance.", Chr(34), strCookieName))
        End If
    End Sub

    ''' <summary>Checks to see if the GET data key exists in this GET data.</summary>
    ''' <param name="strName">The name of the GET data variable you are checking the existance of.</param>
    ''' <returns></returns>
    Public Function doesGETDataExist(strName As String)
        Return getData.ContainsKey(strName)
    End Function

    ''' <summary>Checks to see if the POST data key exists in this POST data.</summary>
    ''' <param name="strName">The name of the POST data variable you are checking the existance of.</param>
    ''' <returns></returns>
    Public Function doesPOSTDataExist(strName As String)
        Return postData.ContainsKey(strName)
    End Function

    ''' <summary>Checks to see if an additional HTTP Request Header has been added to the Class.</summary>
    ''' <param name="strHeaderName">The name of the HTTP Request Header to check the existance of.</param>
    ''' <returns>Boolean value; True if found, False if not found.</returns>
    Public Function doesAdditionalHeaderExist(strHeaderName As String) As Boolean
        Return additionalHTTPHeaders.ContainsKey(strHeaderName.ToLower)
    End Function

    ''' <summary>Checks to see if a cookie has been added to the Class.</summary>
    ''' <param name="strCookieName">The name of the cookie to check the existance of.</param>
    ''' <returns>Boolean value; True if found, False if not found.</returns>
    Public Function doesCookieExist(strCookieName As String) As Boolean
        Return httpCookies.ContainsKey(strCookieName.ToLower)
    End Function

    ''' <summary>Deletes an additional HTTP Request Header from this Class instance.</summary>
    ''' <param name="strHeaderName">The name of the HTTP Request Header delete from this Class instance.</param>
    ''' <param name="throwExceptionIfNotFound">Optional setting, normally set to False. Tells the function if it should throw an exception if the header to be removed doesn't exist.</param>
    ''' <exception cref="additionalHeaderNotFoundException">If this function throws an additionalHeaderNotFoundException, it means that the header you were trying to delete from this Class instance doesn't exist in the Class.</exception>
    Public Sub deleteAdditionalHeader(strHeaderName As String, Optional throwExceptionIfNotFound As Boolean = False)
        If doesAdditionalHeaderExist(strHeaderName) = True Then
            additionalHTTPHeaders.Remove(strHeaderName.ToLower)
        Else
            If throwExceptionIfNotFound = True Then Throw New additionalHeaderNotFoundException(String.Format("The additional HTTP Header named {0}{1}{0} was not found in the Additional HTTP Headers settings for this Class instance.", Chr(34), strHeaderName))
        End If
    End Sub

    ''' <summary>Deletes an HTTP Cookie from this Class instance.</summary>
    ''' <param name="strCookieName">The name of the HTTP Request Header delete from this Class instance.</param>
    ''' <param name="throwExceptionIfNotFound">Optional setting, normally set to False. Tells the function if it should throw an exception if the cookie to be removed doesn't exist.</param>
    ''' <exception cref="cookieNotFoundException">If this function throws a cookieNotFoundException, it means that the header you were trying to delete from this Class instance doesn't exist in the Class.</exception>
    Public Sub deleteCookie(strCookieName As String, Optional throwExceptionIfNotFound As Boolean = False)
        If doesCookieExist(strCookieName) = True Then
            httpCookies.Remove(strCookieName.ToLower)
        Else
            If throwExceptionIfNotFound = True Then Throw New cookieNotFoundException(String.Format("The HTTP Cookie named {0}{1}{0} was not found in the settings for this Class instance.", Chr(34), strCookieName))
        End If
    End Sub

    ''' <summary>Removes a POST data variable from the POST data.</summary>
    ''' <param name="strName">The name of the variable you want to remove.</param>
    ''' <param name="throwExceptionIfNotFound">Optional setting, normally set to False. If this function throws a postDataEntryNotFound, the variable doesn't exist in the POST data.</param>
    Public Sub deletePOSTData(strName As String, Optional throwExceptionIfNotFound As Boolean = False)
        If doesPOSTDataExist(strName) = True Then
            postData.Remove(strName)
        Else
            If throwExceptionIfNotFound = True Then Throw New postDataEntryNotFound(String.Format("The {0}{1}{0} variable doesn't exist in the POST data.", Chr(34), strName))
        End If
    End Sub

    ''' <summary>Removes a GET data variable from the GET data.</summary>
    ''' <param name="strName">The name of the variable you want to remove.</param>
    ''' <param name="throwExceptionIfNotFound">Optional setting, normally set to False. If this function throws a getDataEntryNotFound, the variable doesn't exist in the GET data.</param>
    Public Sub deleteGETData(strName As String, Optional throwExceptionIfNotFound As Boolean = False)
        If doesGETDataExist(strName) = True Then
            getData.Remove(strName)
        Else
            If throwExceptionIfNotFound = True Then Throw New getDataEntryNotFound(String.Format("The {0}{1}{0} variable doesn't exist in the GET data.", Chr(34), strName))
        End If
    End Sub

    ''' <summary>Removes all cookies from this Class instance.</summary>
    Public Sub deleteAllCookies()
        httpCookies.Clear()
    End Sub

    ''' <summary>Removes all additional HTTP Headers from this Class instance.</summary>
    Public Sub deleteAllAdditionalHeaders()
        additionalHTTPHeaders.Clear()
    End Sub

    ''' <summary>Removes all POST data from this Class instance.</summary>
    Public Sub deleteAllPOSTData()
        postData.Clear()
    End Sub

    ''' <summary>Removes all GET data from this Class instance.</summary>
    Public Sub deleteAllGETData()
        getData.Clear()
    End Sub

    ''' <summary>This adds a file to be uploaded to your POST data.</summary>
    ''' <param name="strFormName">The form name of the data to post.</param>
    ''' <param name="strLocalFilePath">The path to the file you want to upload.</param>
    ''' <param name="strRemoteFileName">This is the name that the uploaded file will be called on the remote server. If set to Nothing the program will fill the name in.</param>
    ''' <param name="strContentType">The Content Type of the file you want to upload. You can leave it blank (or set to Nothing) and the program will try and determine what the MIME type of the file you're attaching is.</param>
    ''' <exception cref="FileNotFoundException">If this function throws a FileNotFoundException, the Class wasn't able to find the file that you're trying to attach to the POST data on the local file system.</exception>
    ''' <exception cref="noMimeTypeFoundException">If this function throws a noMimeTypeFoundException, the Class wasn't able to automatically determine the MIME type of the file you're trying to attach to the POST data.</exception>
    ''' <example>httpPostObject.addFileToUpload("file", "C:\My File.txt", "My File.txt", Nothing)</example>
    ''' <example>httpPostObject.addFileToUpload("file", "C:\My File.txt", "My File.txt", "text/plain")</example>
    ''' <example>httpPostObject.addFileToUpload("file", "C:\My File.txt", Nothing, Nothing)</example>
    ''' <example>httpPostObject.addFileToUpload("file", "C:\My File.txt", Nothing, "text/plain")</example>
    Public Sub addFileUpload(strFormName As String, strLocalFilePath As String, strRemoteFileName As String, strContentType As String)
        Dim fileInfo As New FileInfo(strLocalFilePath)

        If fileInfo.Exists = False Then
            Throw New FileNotFoundException("Local file not found.", strLocalFilePath)
        Else
            Dim formFileInstance As New FormFile
            formFileInstance.formName = strFormName
            formFileInstance.localFilePath = strLocalFilePath
            formFileInstance.remoteFileName = strRemoteFileName

            If strContentType Is Nothing Then
                Dim contentType As String
                Dim regPath As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(fileInfo.Extension.ToLower, False)

                If regPath Is Nothing Then
                    Throw New noMimeTypeFoundException("No MIME Type found for " & fileInfo.Extension.ToLower)
                Else
                    contentType = regPath.GetValue("Content Type", Nothing)
                End If

                If contentType = Nothing Then
                    Throw New noMimeTypeFoundException("No MIME Type found for " & fileInfo.Extension.ToLower)
                Else
                    formFileInstance.contentType = contentType
                End If
            Else
                formFileInstance.contentType = strContentType
            End If

            postData.Add(strFormName, formFileInstance)
        End If
    End Sub

    ''' <summary>Gets the HTTP Response Headers that were returned by the HTTP Server after the HTTP request.</summary>
    ''' <param name="throwExceptionIfNoHeaders">Optional setting, normally set to False. Tells the function if it should throw an exception if no HTTP Response Headers are contained in this Class instance.</param>
    ''' <returns>A collection of HTTP Response Headers in a Net.WebHeaderCollection object.</returns>
    ''' <exception cref="noHTTPServerResponseHeadersFoundException">If this function throws a noHTTPServerResponseHeadersFoundException, there are no HTTP Response Headers in this Class instance.</exception>
    Public Function getHTTPResponseHeaders(Optional throwExceptionIfNoHeaders As Boolean = False) As Net.WebHeaderCollection
        If httpResponseHeaders Is Nothing Then
            If throwExceptionIfNoHeaders = True Then
                Throw New noHTTPServerResponseHeadersFoundException("No HTTP Server Response Headers found.")
            Else
                Return Nothing
            End If
        Else
            Return httpResponseHeaders
        End If
    End Function

    ''' <summary>Gets the percentage of the file that's being downloaded from the HTTP Server.</summary>
    ''' <returns>Returns a Short Integer value.</returns>
    Public Function getHTTPDownloadProgressPercentage() As Short
        Return httpDownloadProgressPercentage
    End Function

    ''' <summary>Downloads a file from a web server while feeding back the status of the download. You can find the percentage of the download in the httpDownloadProgressPercentage variable.</summary>
    ''' <param name="fileDownloadURL">The HTTP Path to a file on a remote server to download.</param>
    ''' <param name="localFileName">The path in the local file system to which you are saving the file that's being downloaded.</param>
    ''' <exception cref="Net.WebException">If this function throws a Net.WebException then something failed during the HTTP request.</exception>
    ''' <exception cref="localFileAlreadyExistsException">If this function throws a localFileAlreadyExistsException, the path in the local file system already exists.</exception>
    ''' <exception cref="Exception">If this function throws a general Exception, something really went wrong; something that the function normally doesn't handle.</exception>
    Public Sub downloadFile(fileDownloadURL As String, localFileName As String, Optional throwExceptionIfLocalFileExists As Boolean = False)
        Dim fileWriteStream As FileStream = Nothing

        Try
            If File.Exists(localFileName) = True Then
                If throwExceptionIfLocalFileExists = True Then
                    Throw New localFileAlreadyExistsException(String.Format("The local file found at {0}{1}{0} already exists.", Chr(34), localFileName))
                Else
                    File.Delete(localFileName)
                End If
            End If

            ' A data buffer that holds 4096 bytes or 4 KBs. We use this data buffer to hold the stream of data from the web server.
            Dim dataBuffer As Byte() = New Byte(4095) {}

            Dim httpWebRequest As Net.HttpWebRequest = DirectCast(Net.WebRequest.Create(fileDownloadURL), Net.HttpWebRequest)
            httpWebRequest.Timeout = httpTimeOut
            httpWebRequest.KeepAlive = True

            If boolUseProxy = True Then httpWebRequest.Proxy = Net.WebProxy.GetDefaultProxy

            If strUserAgentString <> Nothing Then httpWebRequest.UserAgent = strUserAgentString
            If httpCookies.Count <> 0 Then getCookies(httpWebRequest)
            If additionalHTTPHeaders.Count <> 0 Then getHeaders(httpWebRequest)

            Dim webResponse As Net.WebResponse = httpWebRequest.GetResponse() ' We now get the web response.

            ' We tell the web server that we can accept a GZIP and Deflate compressed data stream.
            httpWebRequest.Headers.Add(Net.HttpRequestHeader.AcceptEncoding, "gzip, deflate")

            ' Gets the size of the remote file on the web server.
            remoteFileSize = Long.Parse(webResponse.Headers("Content-Length").ToString)

            Dim responseStream As Stream = webResponse.GetResponseStream() ' Gets the response stream.
            fileWriteStream = New FileStream(localFileName, FileMode.Create) ' Creates a file write stream.

            Dim count As Long = responseStream.Read(dataBuffer, 0, dataBuffer.Length) ' Reads some data from the HTTP stream into our data buffer.
            Dim oldCurrentFileSize As Long = 0

            ' We keep looping until all of the data has been downloaded.
            While count <> 0
                fileWriteStream.Write(dataBuffer, 0, count) ' Writes the data directly to disk.
                currentFileSize = fileWriteStream.Length
                httpDownloadProgressPercentage = Math.Round((fileWriteStream.Length / remoteFileSize) * 100, 0) ' Updates the download status progress bar.
                count = responseStream.Read(dataBuffer, 0, dataBuffer.Length) ' Reads more data into our data buffer.
            End While

            fileWriteStream.Close() ' Closes the file stream.
            fileWriteStream.Dispose() ' Disposes the file stream.
        Catch ex As Net.WebException
            If fileWriteStream IsNot Nothing Then
                fileWriteStream.Close() ' Closes the file stream.
                fileWriteStream.Dispose() ' Disposes the file stream.
            End If

            Throw New Net.WebException(ex.Message, ex)
        Catch ex As Threading.ThreadAbortException
            If fileWriteStream IsNot Nothing Then
                fileWriteStream.Close() ' Closes the file stream.
                fileWriteStream.Dispose() ' Disposes the file stream.
            End If
        Catch ex As Exception
            If fileWriteStream IsNot Nothing Then
                fileWriteStream.Close() ' Closes the file stream.
                fileWriteStream.Dispose() ' Disposes the file stream.
            End If
        End Try
    End Sub

    ''' <summary>Performs an HTTP Request for data from a web server.</summary>
    ''' <param name="url">This is the URL that the program will send to the web server in the HTTP request. Do not include any GET variables in the URL, use the addGETData() function before calling this function.</param>
    ''' <param name="httpResponseText">This is a ByRef variable so declare it before passing it to this function, think of this as a pointer. The HTML/text content that the web server on the other end responds with is put into this variable and passed back in a ByRef function.</param>
    ''' <returns>A Boolean value. If the HTTP operation was successful it returns a TRUE value, if not FALSE.</returns>
    ''' <exception cref="Net.WebException">If this function throws a Net.WebException then something failed during the HTTP request.</exception>
    ''' <exception cref="Exception">If this function throws a general Exception, something really went wrong; something that the function normally doesn't handle.</exception>
    ''' <example>httpPostObject.getWebData("http://www.myserver.com/mywebpage", httpResponseText)</example>
    Public Function getWebData(ByVal url As String, ByRef httpResponseText As String) As Boolean
        Try
            If getData.Count <> 0 Then url &= "?" & getGETDataString()

            Dim httpWebRequest As Net.HttpWebRequest = DirectCast(Net.WebRequest.Create(url), Net.HttpWebRequest)
            httpWebRequest.Timeout = httpTimeOut

            If boolUseProxy = True Then httpWebRequest.Proxy = Net.WebProxy.GetDefaultProxy

            If strUserAgentString <> Nothing Then httpWebRequest.UserAgent = strUserAgentString
            If httpCookies.Count <> 0 Then getCookies(httpWebRequest)
            If additionalHTTPHeaders.Count <> 0 Then getHeaders(httpWebRequest)

            If postData.Count = 0 Then
                httpWebRequest.Method = "GET"
            Else
                httpWebRequest.Method = "POST"
                Dim postDataString As String = getPOSTDataString()
                httpWebRequest.ContentType = "application/x-www-form-urlencoded"
                httpWebRequest.ContentLength = postDataString.Length

                Dim httpRequestWriter = New StreamWriter(httpWebRequest.GetRequestStream())
                httpRequestWriter.Write(postDataString)
                httpRequestWriter.Close()
                httpRequestWriter.Dispose()
                httpRequestWriter = Nothing
            End If

            Dim httpWebResponse As Net.WebResponse = httpWebRequest.GetResponse()
            Dim httpInStream As New StreamReader(httpWebResponse.GetResponseStream())
            Dim httpTextOutput As String = httpInStream.ReadToEnd.Trim()
            httpResponseHeaders = httpWebResponse.Headers

            httpInStream.Close()
            httpInStream.Dispose()
            httpWebRequest = Nothing

            httpResponseText = convertLineFeeds(httpTextOutput).Trim()
            Return True
        Catch ex As Net.WebException
            Throw New Net.WebException(ex.Message, ex)
            Return False
        Catch ex As Exception
            Throw New Exception(ex.Message, ex)
            Return False
        End Try
    End Function

    ''' <summary>Sends data to a URL of your choosing.</summary>
    ''' <param name="url">This is the URL that the program will send to the web server in the HTTP request. Do not include any GET variables in the URL, use the addGETData() function before calling this function.</param>
    ''' <param name="httpResponseText">This is a ByRef variable so declare it before passing it to this function, think of this as a pointer. The HTML/text content that the web server on the other end responds with is put into this variable and passed back in a ByRef function.</param>
    ''' <returns>A Boolean value. If the HTTP operation was successful it returns a TRUE value, if not FALSE.</returns>
    ''' <exception cref="Net.WebException">If this function throws a Net.WebException then something failed during the HTTP request.</exception>
    ''' <exception cref="postDataMissingException">If this function throws an postDataMissingException, the Class has nothing to upload so why continue?</exception>
    ''' <exception cref="Exception">If this function throws a general Exception, something really went wrong; something that the function normally doesn't handle.</exception>
    ''' <example>httpPostObject.uploadData("http://www.myserver.com/myscript", httpResponseText)</example>
    Public Function uploadData(ByVal url As String, ByRef httpResponseText As String) As Boolean
        Try
            If postData.Count = 0 Then Throw New postDataMissingException("Your HTTP Request contains no POST data. Please add some data to POST before calling this function.")
            If getData.Count <> 0 Then url &= "?" & getGETDataString()

            Dim boundary As String = "---------------------------" & Now.Ticks.ToString("x")
            Dim boundaryBytes As Byte() = Text.Encoding.ASCII.GetBytes((Convert.ToString(vbCr & vbLf & "--") & boundary) & vbCr & vbLf)

            Dim httpWebRequest As Net.HttpWebRequest = DirectCast(Net.WebRequest.Create(url), Net.HttpWebRequest)
            httpWebRequest.Timeout = httpTimeOut

            If boolUseProxy = True Then httpWebRequest.Proxy = Net.WebProxy.GetDefaultProxy

            httpWebRequest.KeepAlive = True
            httpWebRequest.ContentType = "multipart/form-data; boundary=" & boundary
            httpWebRequest.Method = "POST"

            If strUserAgentString <> Nothing Then httpWebRequest.UserAgent = strUserAgentString
            If httpCookies.Count <> 0 Then getCookies(httpWebRequest)
            If additionalHTTPHeaders.Count <> 0 Then getHeaders(httpWebRequest)

            If postData.Count <> 0 Then
                Dim httpRequestWriter As Stream = httpWebRequest.GetRequestStream()
                Dim header As String, fileInfo As FileInfo, formFileObjectInstance As FormFile
                Dim bytes As Byte(), buffer As Byte(), fileStream As FileStream, data As String

                For Each entry As KeyValuePair(Of String, Object) In postData
                    httpRequestWriter.Write(boundaryBytes, 0, boundaryBytes.Length)

                    If TypeOf entry.Value Is FormFile Then
                        formFileObjectInstance = DirectCast(entry.Value, FormFile)

                        If formFileObjectInstance.remoteFileName = Nothing Then
                            fileInfo = New FileInfo(formFileObjectInstance.localFilePath)

                            header = String.Format("Content-Disposition: form-data; name={0}{1}{0}; filename={0}{2}{0}", Chr(34), entry.Key, fileInfo.Name) & vbCrLf & "Content-Type: " & formFileObjectInstance.contentType & vbCrLf & vbCrLf
                        Else
                            header = String.Format("Content-Disposition: form-data; name={0}{1}{0}; filename={0}{2}{0}", Chr(34), entry.Key, formFileObjectInstance.remoteFileName) & vbCrLf & "Content-Type: " & formFileObjectInstance.contentType & vbCrLf & vbCrLf
                        End If

                        bytes = Text.Encoding.UTF8.GetBytes(header)
                        httpRequestWriter.Write(bytes, 0, bytes.Length)

                        fileStream = New FileStream(formFileObjectInstance.localFilePath, FileMode.Open)
                        buffer = New Byte(32768) {}

                        While fileStream.Read(buffer, 0, buffer.Length) <> 0
                            httpRequestWriter.Write(buffer, 0, buffer.Length)
                        End While

                        fileStream.Close()
                        fileStream.Dispose()
                        fileStream = Nothing
                    Else
                        data = String.Format("Content-Disposition: form-data; name={0}{1}{0}{2}{2}{3}", Chr(34), entry.Key, vbCrLf, entry.Value)
                        bytes = Text.Encoding.UTF8.GetBytes(data)
                        httpRequestWriter.Write(bytes, 0, bytes.Length)
                    End If
                Next

                Dim trailer As Byte() = Text.Encoding.ASCII.GetBytes(vbCrLf & "--" & boundary & "--" & vbCrLf)
                httpRequestWriter.Write(trailer, 0, trailer.Length)
                httpRequestWriter.Close()
            End If

            Dim httpWebResponse As Net.WebResponse = httpWebRequest.GetResponse()
            Dim httpInStream As New StreamReader(httpWebResponse.GetResponseStream())
            Dim httpTextOutput As String = httpInStream.ReadToEnd.Trim()
            httpResponseHeaders = httpWebResponse.Headers

            httpInStream.Close()
            httpInStream.Dispose()
            httpWebRequest = Nothing

            httpResponseText = convertLineFeeds(httpTextOutput).Trim()
            Return True
        Catch ex As Net.WebException
            Throw New Net.WebException(ex.Message, ex)
            Return False
        Catch ex As Exception
            Throw New Exception(ex.Message, ex)
            Return False
        End Try
    End Function

    Private Sub getCookies(ByRef httpWebRequest As Net.HttpWebRequest)
        Dim cookieContainer As New Net.CookieContainer
        For Each entry As KeyValuePair(Of String, cookieDetails) In httpCookies
            cookieContainer.Add(New Net.Cookie(entry.Key, entry.Value.cookieData, entry.Value.cookiePath, entry.Value.cookieDomain))
        Next
        httpWebRequest.CookieContainer = cookieContainer
    End Sub

    Private Sub getHeaders(ByRef httpWebRequest As Net.HttpWebRequest)
        For Each entry As KeyValuePair(Of String, String) In additionalHTTPHeaders
            httpWebRequest.Headers(entry.Key) = entry.Value
        Next
    End Sub

    Private Function convertLineFeeds(input As String) As String
        ' Checks to see if the file is in Windows linefeed format or UNIX linefeed format.
        If input.Contains(vbCrLf) Then
            Return input ' It's in Windows linefeed format so we return the output as is.
        Else
            Return input.Replace(vbLf, vbCrLf) ' It's in UNIX linefeed format so we have to convert it to Windows before we return the output.
        End If
    End Function

    Private Function getPOSTDataString() As String
        Dim postDataString As String = ""
        For Each entry As KeyValuePair(Of String, Object) In postData
            If TypeOf entry.Value IsNot FormFile Then
                postDataString &= entry.Key.Trim & "=" & Web.HttpUtility.UrlEncode(entry.Value.Trim) & "&"
            End If
        Next

        If postDataString.EndsWith("&") Then
            postDataString = postDataString.Substring(0, postDataString.Length - 1)
        End If

        Return postDataString
    End Function

    Private Function getGETDataString() As String
        Dim getDataString As String = ""
        For Each entry As KeyValuePair(Of String, String) In getData
            getDataString &= entry.Key.Trim & "=" & Web.HttpUtility.UrlEncode(entry.Value.Trim) & "&"
        Next

        If getDataString.EndsWith("&") Then
            getDataString = getDataString.Substring(0, getDataString.Length - 1)
        End If

        Return getDataString
    End Function

    Private Function fileSizeToHumanReadableFormat(ByVal size As Long, Optional roundToNearestWholeNumber As Boolean = False) As String
        Dim result As String

        If size <= (2 ^ 10) Then
            result = size & " Bytes"
        ElseIf size > (2 ^ 10) And size <= (2 ^ 20) Then
            If roundToNearestWholeNumber = True Then
                result = Math.Round(size / (2 ^ 10), 0) & " KBs"
            Else
                result = Math.Round(size / (2 ^ 10), 2) & " KBs"
            End If
        ElseIf size > (2 ^ 20) And size <= (2 ^ 30) Then
            If roundToNearestWholeNumber = True Then
                result = Math.Round(size / (2 ^ 20), 0) & " MBs"
            Else
                result = Math.Round(size / (2 ^ 20), 2) & " MBs"
            End If
        ElseIf size > (2 ^ 30) And size <= (2 ^ 40) Then
            If roundToNearestWholeNumber = True Then
                result = Math.Round(size / (2 ^ 30), 0) & " GBs"
            Else
                result = Math.Round(size / (2 ^ 30), 2) & " GBs"
            End If
        ElseIf size > (2 ^ 40) And size <= (2 ^ 50) Then
            If roundToNearestWholeNumber = True Then
                result = Math.Round(size / (2 ^ 40), 0) & " TBs"
            Else
                result = Math.Round(size / (2 ^ 40), 2) & " TBs"
            End If
        ElseIf size > (2 ^ 50) And size <= (2 ^ 60) Then
            If roundToNearestWholeNumber = True Then
                result = Math.Round(size / (2 ^ 50), 0) & " PBs"
            Else
                result = Math.Round(size / (2 ^ 50), 2) & " PBs"
            End If
        Else
            result = "(None)"
        End If

        Return result
    End Function

    Private Function doWeHaveAnInternetConnection() As Boolean
        Try
            Dim ping As New Net.NetworkInformation.Ping()

            If ping.Send("8.8.8.8").Status = Net.NetworkInformation.IPStatus.Success Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function
End Class