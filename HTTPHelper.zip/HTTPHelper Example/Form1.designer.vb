﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnGetWebPageData = New System.Windows.Forms.Button()
        Me.postDataExample = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.btnDownloadFile = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnUpload = New System.Windows.Forms.Button()
        Me.btnStopDownload = New System.Windows.Forms.Button()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'btnGetWebPageData
        '
        Me.btnGetWebPageData.Location = New System.Drawing.Point(12, 12)
        Me.btnGetWebPageData.Name = "btnGetWebPageData"
        Me.btnGetWebPageData.Size = New System.Drawing.Size(158, 23)
        Me.btnGetWebPageData.TabIndex = 0
        Me.btnGetWebPageData.Text = "Get Web Page Data"
        Me.btnGetWebPageData.UseVisualStyleBackColor = True
        '
        'postDataExample
        '
        Me.postDataExample.Location = New System.Drawing.Point(176, 12)
        Me.postDataExample.Name = "postDataExample"
        Me.postDataExample.Size = New System.Drawing.Size(158, 23)
        Me.postDataExample.TabIndex = 1
        Me.postDataExample.Text = "Post Data to Web Site"
        Me.postDataExample.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser1.Location = New System.Drawing.Point(12, 108)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(804, 269)
        Me.WebBrowser1.TabIndex = 2
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.Location = New System.Drawing.Point(12, 383)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(804, 186)
        Me.TextBox1.TabIndex = 3
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(12, 41)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(485, 23)
        Me.ProgressBar1.TabIndex = 4
        '
        'btnDownloadFile
        '
        Me.btnDownloadFile.Location = New System.Drawing.Point(558, 12)
        Me.btnDownloadFile.Name = "btnDownloadFile"
        Me.btnDownloadFile.Size = New System.Drawing.Size(108, 23)
        Me.btnDownloadFile.TabIndex = 5
        Me.btnDownloadFile.Text = "Download File"
        Me.btnDownloadFile.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Label1"
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(340, 12)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(75, 23)
        Me.btnUpload.TabIndex = 7
        Me.btnUpload.Text = "Upload File"
        Me.btnUpload.UseVisualStyleBackColor = True
        '
        'btnStopDownload
        '
        Me.btnStopDownload.Enabled = False
        Me.btnStopDownload.Location = New System.Drawing.Point(672, 12)
        Me.btnStopDownload.Name = "btnStopDownload"
        Me.btnStopDownload.Size = New System.Drawing.Size(108, 23)
        Me.btnStopDownload.TabIndex = 8
        Me.btnStopDownload.Text = "Stop Download"
        Me.btnStopDownload.UseVisualStyleBackColor = True
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.FileName = "OpenFileDialog1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(828, 581)
        Me.Controls.Add(Me.btnStopDownload)
        Me.Controls.Add(Me.btnUpload)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDownloadFile)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.postDataExample)
        Me.Controls.Add(Me.btnGetWebPageData)
        Me.Name = "Form1"
        Me.Text = "HTTPHelper Example"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnGetWebPageData As Button
    Friend WithEvents postDataExample As Button
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents btnDownloadFile As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnUpload As Button
    Friend WithEvents btnStopDownload As Button
    Friend WithEvents OpenFileDialog As OpenFileDialog
End Class
