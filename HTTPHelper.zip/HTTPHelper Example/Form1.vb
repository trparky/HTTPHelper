﻿Public Class Form1
    Private Sub btnGetWebPageData_Click(sender As Object, e As EventArgs) Handles btnGetWebPageData.Click
        Try
            Dim strServerResponse As String = Nothing

            Dim httpHelper As New Tom.httpHelper()
            httpHelper.setUserAgent("Microsoft .NET") ' Set our User Agent String.
            httpHelper.addGETData("test3", "value3")
            httpHelper.addHTTPCookie("mycookie", "my cookie contents", "www.toms-world.org", "/")
            httpHelper.addHTTPHeader("myheader", "my header contents")

            If httpHelper.getWebData("http://www.toms-world.org/httphelper.php", strServerResponse) = True Then
                WebBrowser1.DocumentText = strServerResponse
                TextBox1.Text = httpHelper.getHTTPResponseHeaders(True).ToString
            End If
        Catch ex As Net.WebException
            ' You can handle web exceptions different than normal exceptions with this code.
        Catch ex As Exception
            MsgBox(ex.Message & " " & ex.StackTrace)
        End Try
    End Sub

    Private Sub postDataExample_Click(sender As Object, e As EventArgs) Handles postDataExample.Click
        Try
            Dim strServerResponse As String = Nothing

            Dim httpHelper As New Tom.httpHelper()
            httpHelper.setUserAgent("Microsoft .NET") ' Set our User Agent String.
            httpHelper.addHTTPCookie("mycookie", "my cookie contents", "www.toms-world.org", "/")
            httpHelper.addHTTPHeader("myheader", "my header contents")
            httpHelper.addPOSTData("test1", "value1")
            httpHelper.addPOSTData("test2", "value2")
            httpHelper.addGETData("test3", "value3")
            httpHelper.addPOSTData("major", "3")
            httpHelper.addPOSTData("minor", "9")
            httpHelper.addPOSTData("build", "6")

            If httpHelper.getWebData("http://www.toms-world.org/httphelper.php", strServerResponse) = True Then
                WebBrowser1.DocumentText = strServerResponse
                TextBox1.Text = httpHelper.getHTTPResponseHeaders().ToString

                'For Each strHeaderName As String In httpHelper.getHTTPResponseHeaders
                '    MsgBox(strHeaderName & " = " & httpHelper.getHTTPResponseHeaders.Item(strHeaderName))
                'Next
            End If
        Catch ex As Net.WebException
            MsgBox(ex.Message & " " & ex.StackTrace)
        End Try
    End Sub

    Sub updateStatus(ByVal httpHelper As Tom.httpHelper)
        ' This gets our percentage of the file that's been downloaded.
        Dim percentage As Short = httpHelper.getHTTPDownloadProgressPercentage()

        While percentage <> 100 ' We loop while the percentage is not 100.
            Label1.Text = String.Format("Downloaded {0} of {1} ({2}%)", httpHelper.getHTTPDownloadLocalFileSize(), httpHelper.getHTTPDownloadRemoteFileSize(), percentage)
            ProgressBar1.Value = percentage ' Set the progress bar the percentage value.
            Threading.Thread.Sleep(1000) ' Let's sleep for a second.
            percentage = httpHelper.getHTTPDownloadProgressPercentage() ' Get the new percentage value.
        End While
    End Sub

    Dim downloadThread As Threading.Thread

    Private Sub btnDownloadFile_Click(sender As Object, e As EventArgs) Handles btnDownloadFile.Click
        ' First we create our httpHelper Class instance.
        Dim httpHelper As New Tom.httpHelper()
        httpHelper.setUserAgent("Microsoft .NET") ' Set our User Agent String.

        ' This example we're going to be downloading a file so this is going to take some time. We need multithreading!

        ' We want to give the user some status on the download so we need a thread to do it.
        Dim statusUpdatingThread As New Threading.Thread(Sub()
                                                             Try
                                                                 updateStatus(httpHelper)
                                                             Catch ex As Exception
                                                             End Try
                                                         End Sub)
        statusUpdatingThread.Start() ' Start our status update thread.

        ' Now we need to create our download thread.
        downloadThread = New Threading.Thread(Sub()
                                                  Dim urlToFileToBeDownloaded As String = "http://releases.ubuntu.com/16.04/ubuntu-16.04-desktop-amd64.iso"
                                                  Dim pathToDownloadFileTo As String = "S:\ubuntu-16.04-desktop-amd64.iso"

                                                  Try
                                                      btnStopDownload.Enabled = True
                                                      btnDownloadFile.Enabled = False

                                                      ' We use the downloadFile() function which first calls for the URL and then the path to a place on the local file system to save it. This function is why we need multithreading, this will take a long time to do.
                                                      httpHelper.downloadFile(urlToFileToBeDownloaded, pathToDownloadFileTo)
                                                      statusUpdatingThread.Abort() ' Stop the status updating thread.
                                                      btnDownloadFile.Enabled = True
                                                      btnStopDownload.Enabled = False
                                                      MsgBox("Download complete.") ' And tell the user that the download is complete.
                                                  Catch ex As Net.WebException
                                                      statusUpdatingThread.Abort()
                                                      btnDownloadFile.Enabled = True
                                                      btnStopDownload.Enabled = False
                                                      MsgBox(ex.Message & " " & ex.StackTrace)
                                                  Catch ex As Threading.ThreadAbortException
                                                      statusUpdatingThread.Abort()
                                                      btnDownloadFile.Enabled = True
                                                      btnStopDownload.Enabled = False
                                                      If IO.File.Exists(pathToDownloadFileTo) Then IO.File.Delete(pathToDownloadFileTo)
                                                      MsgBox("Download aborted.") ' And tell the user that the download is aborted.
                                                  End Try
                                              End Sub)
        downloadThread.Start() ' Starts our download thread.
    End Sub

    Private Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
        Try
            OpenFileDialog.Title = "Browse for file to upload..."
            OpenFileDialog.FileName = Nothing
            OpenFileDialog.Filter = "Image Files (JPEG, PNG)|*.png;*.jpg;*.jpeg"

            If OpenFileDialog.ShowDialog() = DialogResult.OK Then
                Dim strServerResponse As String = Nothing

                Dim httpHelper As New Tom.httpHelper()
                httpHelper.setHTTPTimeout(10)
                httpHelper.setUserAgent("Microsoft .NET") ' Set our User Agent String.
                httpHelper.addHTTPCookie("mycookie", "my cookie contents", "www.toms-world.org", "/")
                httpHelper.addHTTPHeader("myheader", "my header contents")
                httpHelper.addPOSTData("test1", "value1")
                httpHelper.addPOSTData("test2", "value2")
                httpHelper.addGETData("test3", "value3")
                httpHelper.addFileUpload("myfileupload", OpenFileDialog.FileName, Nothing, Nothing)

                If httpHelper.uploadData("http://www.toms-world.org/httphelper.php", strServerResponse) = True Then
                    WebBrowser1.DocumentText = strServerResponse
                    TextBox1.Text = httpHelper.getHTTPResponseHeaders().ToString
                End If
            End If
        Catch ex As Net.WebException
            MsgBox(ex.Message & " " & ex.StackTrace)
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Control.CheckForIllegalCrossThreadCalls = False
    End Sub

    Private Sub btnStopDownload_Click(sender As Object, e As EventArgs) Handles btnStopDownload.Click
        downloadThread.Abort()
    End Sub
End Class
